#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
{fileheader}


def main():
	
	return 0

if __name__ == '__main__':
	main()

