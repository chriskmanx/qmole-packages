npm-start(1) -- Start a package
===============================

## SYNOPSIS

    npm start <name>[@<version>] [<name>[@<version>] ...]

## DESCRIPTION

This runs a package's "start" script, if one was provided.

If no version is specified, then it starts the "active" version.
