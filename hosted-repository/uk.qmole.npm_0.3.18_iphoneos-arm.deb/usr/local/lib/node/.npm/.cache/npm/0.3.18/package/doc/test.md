npm-test(1) -- Test a package
=============================

## SYNOPSIS

      npm test <name>[@<version>] [<name>[@<version>] ...]

## DESCRIPTION

This runs a package's "test" script, if one was provided.

If no version is specified, then it tests the "active" version.
