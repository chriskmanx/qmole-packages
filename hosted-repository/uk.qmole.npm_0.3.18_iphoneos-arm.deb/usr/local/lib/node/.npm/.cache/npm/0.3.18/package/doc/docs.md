npm-docs(1) -- Docs for a package in a web browser maybe
========================================================

## SYNOPSIS

    npm docs <pkgname>

## DESCRIPTION

This command tries to guess at the likely location of a package's
documentation URL, and then tries to open it using the `--browser`
config param, which defaults to `"open"` because that works on a mac.

This is an experimental command.  It may disappear or change radically.
