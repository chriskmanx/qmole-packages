npm-stop(1) -- Stop a package
=============================

## SYNOPSIS

    npm stop <name>[@<version>] [<name>[@<version>] ...]

## DESCRIPTION

This runs a package's "stop" script, if one was provided.

If no version is specified, then it stops the "active" version.
