npm-deactivate(1) -- Deactivate the active version of a package
===============================================================

## SYNOPSIS

    npm deactivate <name>

## DESCRIPTION

If there's an active version of the package, this will unlink it from that
preferential position.

## SEE ALSO

npm-activate(1)
