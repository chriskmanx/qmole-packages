# vtcl.vtcl-8.6 
This repository is for people that are interested in vTcl (Visual TCL)

vTcl is an un-paralleled GUI builder that is based on TCL/TK, written in TCL/TK and generates
a 'ready-to-use' application in TCL/TK. 

It needs nothing but TCL/TK ... which follows the "Pure TCL" idea perfectly ...

      Build it ... Save it ... Run it ...

TK was used by some other languages like PERL & Python through the TKinter module that provided
these 'graphics-less' environments with graphical components from TK.

For details on TCL/TK see: http://tcl.tk/

The still 'official' vTcl pages can be found at: http://vtcl.sourceforge.net/
The supplied release 1.6.1a1 only works up to TCL/TK-8.4

Here is a vTcl version prepared to work with the recent TCL/TK release 8.6

See the wiki (tab above) for preliminary download packages.

--------------
2016-02-20/hph
