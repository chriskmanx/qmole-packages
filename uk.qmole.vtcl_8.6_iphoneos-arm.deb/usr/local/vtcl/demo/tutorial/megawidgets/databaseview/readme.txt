To run the example:

- cd to the sample directory

- start it from a command line:

wish databaseview_test.tcl

  or

- double-click on databaseview_test.tcl in the Windows Explorer

- click on the "Test Now!" button

Database widget will open the database. Look at the "Layout" and "Records" tabs.

NOTE: this sample requires the Mk4tcl database package. This package
      comes standard with the latest version of ActiveTcl, 8.4.2