/* claws-features.h.  Generated from claws-features.h.in by configure.  */
/* #undef HAVE_APACHE_FNMATCH */
/* #undef HAVE_DBUS_GLIB */
#define HAVE_DIRENT_D_TYPE 1
/* #undef HAVE_GPGME_PKA_TRUST */
/* #undef HAVE_LIBCOMPFACE */
#define HAVE_LIBETPAN 1
#define HAVE_LIBSM 1
/* #undef HAVE_NETWORKMANAGER_SUPPORT */
#define HAVE_STARTUP_NOTIFICATION 1
/* #undef HAVE_VALGRIND */
#define USE_BOGOFILTER_PLUGIN 1
#define USE_ENCHANT 1
#define USE_GNUTLS 1
/* #undef USE_GPGME */
/* #undef USE_JPILOT */
/* #undef USE_LDAP */
/* #undef USE_LDAP_TLS */
/* #undef USE_NEW_ADDRBOOK */
#define USE_PTHREAD 1
/* #undef USE_SPAMASSASSIN_PLUGIN */
/* #undef MAEMO */
/* #undef CHINOOK */
/* #undef __CYGWIN__ */
