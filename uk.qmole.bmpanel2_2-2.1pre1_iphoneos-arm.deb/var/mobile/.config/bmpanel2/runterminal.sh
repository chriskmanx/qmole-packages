#!/bin/bash
herbstclient use Terminal
xpause 1 &
ivte -ls -fn "Monospace 14" &



